
██████╗░███████╗░█████╗░██████╗░███╗░░░███╗███████╗
██╔══██╗██╔════╝██╔══██╗██╔══██╗████╗░████║██╔════╝
██████╔╝█████╗░░███████║██║░░██║██╔████╔██║█████╗░░
██╔══██╗██╔══╝░░██╔══██║██║░░██║██║╚██╔╝██║██╔══╝░░
██║░░██║███████╗██║░░██║██████╔╝██║░╚═╝░██║███████╗
╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝╚═════╝░╚═╝░░░░░╚═╝╚══════╝

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/X8X6BF1SS)
# dittodance
a html just for fun ;)
in the index.html file go to lines 14 and 15, replace the link with the link of the song you want to put
go to https://vocaroo.com/upload
(for the tutorial to grab the file link go to https://drive.google.com/file/d/1WlbB5LAH4kpmlOfylASmV13Y8jajdjGe/view?usp=sharing)
to upload your audio.
upload these files (README.md NO) to the hosting site and enjoy (I use altervista to host the site)

Have Fun ;P

ITALIANO

un html solo per divertimento ;)
nel file index.html vai alle righe 14 e 15, sostituisci il link con il link della canzone che vuoi mettere
vai su https://vocaroo.com/upload
(per il tutorial per prendere il collegamento del file, vai a https://drive.google.com/file/d/1WlbB5LAH4kpmlOfylASmV13Y8jajdjGe/view?usp=sharing)
per caricare il tuo audio.
carica questi file (README.md NO) sul sito di hosting e divertiti (io uso altervista per ospitare il sito)

Buon Divertimento ;P

lol
